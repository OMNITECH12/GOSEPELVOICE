import { GoogleGenAI, Type } from "@google/genai";
import { QuizQuestion, Devotional } from '../types';

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY is missing.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const generateDailyDevotional = async (topic?: string): Promise<Devotional | null> => {
  const ai = getAiClient();
  if (!ai) return null;

  const prompt = topic 
    ? `Write a short, uplifting Christian devotional about "${topic}".` 
    : `Write a short, uplifting Christian devotional based on a random encouraging bible verse.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: "You are a wise and compassionate pastor. Output JSON only.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            scripture: { type: Type.STRING, description: "The bible verse reference and text" },
            content: { type: Type.STRING, description: "The main devotional text, about 150 words" },
            prayer: { type: Type.STRING, description: "A short closing prayer" }
          },
          required: ["title", "scripture", "content", "prayer"]
        }
      }
    });

    const text = response.text;
    if (!text) return null;
    return JSON.parse(text) as Devotional;
  } catch (error) {
    console.error("Devotional generation failed", error);
    return null;
  }
};

export const generateQuiz = async (difficulty: 'easy' | 'hard' = 'easy'): Promise<QuizQuestion[]> => {
  const ai = getAiClient();
  if (!ai) return [];

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate 5 ${difficulty} bible trivia questions.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: "4 possible answers"
              },
              answer: { type: Type.STRING, description: "The correct answer from the options" }
            },
            required: ["question", "options", "answer"]
          }
        }
      }
    });

    const text = response.text;
    if (!text) return [];
    return JSON.parse(text) as QuizQuestion[];
  } catch (error) {
    console.error("Quiz generation failed", error);
    return [];
  }
};