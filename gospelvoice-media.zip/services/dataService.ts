import { MediaItem, MediaType, AdminUser } from '../types';

const MEDIA_KEY = 'gv_media_items';
const ADMIN_KEY = 'gv_admins';

const INITIAL_MEDIA: MediaItem[] = [
  { id: '1', title: 'Amazing Grace - Live Worship', author: 'GospelVoice Choir', type: MediaType.MUSIC, description: 'A soul-stirring rendition of the classic hymn.', thumbnailUrl: 'https://picsum.photos/id/314/400/300' },
  { id: '2', title: 'Faith in Hard Times', author: 'Pastor John Doe', type: MediaType.SERMON, description: 'Understanding God\'s plan when the road gets rough.', thumbnailUrl: 'https://picsum.photos/id/452/400/300', duration: '45:20' },
  { id: '3', title: 'Walking in Spirit', author: 'Prophet Jane', type: MediaType.EBOOK, description: 'A comprehensive guide to spiritual growth.', thumbnailUrl: 'https://picsum.photos/id/366/400/300' },
  { id: '4', title: 'Sunday Service Highlights', author: 'GV Media Team', type: MediaType.VIDEO, description: 'Recap of last Sunday\'s powerful move of God.', thumbnailUrl: 'https://picsum.photos/id/326/400/300', duration: '12:05' },
  { id: '5', title: 'The Power of Prayer', author: 'Podcast Team', type: MediaType.PODCAST, description: 'Weekly discussion on effective prayer strategies.', thumbnailUrl: 'https://picsum.photos/id/453/400/300', duration: '28:00' },
  { id: '6', title: 'Healing Streams', author: 'Worship Band', type: MediaType.MUSIC, description: 'Instrumental worship for meditation.', thumbnailUrl: 'https://picsum.photos/id/338/400/300' },
];

const INITIAL_ADMINS: AdminUser[] = [
  { id: '1', name: 'Main Admin', email: 'admin@gospelvoice.media', role: 'Super Admin', password: 'admin' }
];

export const getMedia = (): MediaItem[] => {
  try {
    const stored = localStorage.getItem(MEDIA_KEY);
    if (stored) return JSON.parse(stored);
  } catch (e) {
    console.error("Error loading media", e);
  }
  localStorage.setItem(MEDIA_KEY, JSON.stringify(INITIAL_MEDIA));
  return INITIAL_MEDIA;
};

export const saveMedia = (items: MediaItem[]) => {
  localStorage.setItem(MEDIA_KEY, JSON.stringify(items));
};

export const getAdmins = (): AdminUser[] => {
  try {
    const stored = localStorage.getItem(ADMIN_KEY);
    if (stored) return JSON.parse(stored);
  } catch (e) {
    console.error("Error loading admins", e);
  }
  localStorage.setItem(ADMIN_KEY, JSON.stringify(INITIAL_ADMINS));
  return INITIAL_ADMINS;
};

export const saveAdmins = (admins: AdminUser[]) => {
  localStorage.setItem(ADMIN_KEY, JSON.stringify(admins));
};