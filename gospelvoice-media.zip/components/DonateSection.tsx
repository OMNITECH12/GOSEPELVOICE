import React from 'react';
import { IconHeart } from './Icons';

const DonateSection: React.FC = () => {
  return (
    <section id="donate" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto bg-gradient-to-br from-brand-900 to-brand-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row text-white">
          
          <div className="p-10 md:p-14 md:w-3/5 flex flex-col justify-center">
            <div className="flex items-center gap-3 mb-6">
               <div className="bg-white/20 p-2 rounded-full">
                  <IconHeart className="w-6 h-6 text-gold-400 fill-current" />
               </div>
               <h2 className="text-3xl font-serif font-bold">Support Our Ministry</h2>
            </div>
            <p className="text-brand-100 mb-8 text-lg leading-relaxed">
              Your generosity helps us spread the Gospel to the ends of the earth. Help us keep this platform free for everyone.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="px-8 py-3 bg-gold-500 text-white font-bold rounded shadow-lg hover:bg-gold-600 transition-colors text-center">
                Donate Now
              </button>
              <button className="px-8 py-3 bg-transparent border border-white/30 text-white font-bold rounded hover:bg-white/10 transition-colors text-center">
                Learn More
              </button>
            </div>
          </div>
          
          <div className="relative md:w-2/5 bg-gray-900">
             <img 
                src="https://picsum.photos/id/447/600/800" 
                alt="Worship" 
                className="w-full h-full object-cover opacity-60"
             />
             <div className="absolute bottom-0 left-0 w-full p-8 bg-gradient-to-t from-black/80 to-transparent">
                <p className="italic font-serif text-lg">"God loves a cheerful giver."</p>
                <p className="text-sm text-gray-300 mt-1">— 2 Corinthians 9:7</p>
             </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default DonateSection;