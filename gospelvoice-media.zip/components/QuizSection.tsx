import React, { useState } from 'react';
import { generateQuiz } from '../services/geminiService';
import { QuizQuestion } from '../types';
import { IconBrain } from './Icons';

const QuizSection: React.FC = () => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [loading, setLoading] = useState(false);
  const [gameStatus, setGameStatus] = useState<'idle' | 'playing' | 'finished'>('idle');
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);

  const startGame = async () => {
    setLoading(true);
    const quizData = await generateQuiz('easy');
    setQuestions(quizData);
    setLoading(false);
    setCurrentIndex(0);
    setScore(0);
    setGameStatus('playing');
    setShowResult(false);
    setSelectedOption(null);
  };

  const handleAnswer = (option: string) => {
    setSelectedOption(option);
    setShowResult(true);
    
    if (option === questions[currentIndex].answer) {
      setScore(prev => prev + 1);
    }

    setTimeout(() => {
      if (currentIndex < questions.length - 1) {
        setCurrentIndex(prev => prev + 1);
        setSelectedOption(null);
        setShowResult(false);
      } else {
        setGameStatus('finished');
      }
    }, 2000);
  };

  return (
    <section id="quiz" className="py-20 bg-brand-900 text-white relative overflow-hidden">
        {/* Background decorations */}
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/diamond-upholstery.png')] opacity-10"></div>
        
        <div className="container mx-auto px-6 relative z-10 text-center">
            <div className="mb-10">
                <span className="text-gold-500 font-bold tracking-wider uppercase text-sm">Interactive Learning</span>
                <h2 className="font-serif text-4xl font-bold mt-2">Bible Knowledge Quiz</h2>
                <p className="text-brand-200 mt-4 max-w-2xl mx-auto">Test your knowledge of the scriptures with our AI-powered quiz engine. New questions every time!</p>
            </div>

            <div className="max-w-2xl mx-auto bg-white text-gray-800 rounded-xl shadow-2xl overflow-hidden min-h-[400px] flex flex-col">
                {gameStatus === 'idle' && (
                    <div className="flex-grow flex flex-col items-center justify-center p-12">
                        <div className="bg-brand-100 p-6 rounded-full mb-6 text-brand-600">
                            <IconBrain className="w-12 h-12" />
                        </div>
                        <h3 className="text-2xl font-bold mb-2">Ready to begin?</h3>
                        <p className="text-gray-500 mb-8">5 Questions • Easy/Medium Difficulty</p>
                        <button 
                            onClick={startGame}
                            disabled={loading}
                            className="px-8 py-3 bg-brand-600 text-white font-bold rounded-lg hover:bg-brand-700 transition-all disabled:opacity-50"
                        >
                            {loading ? 'Generating Quiz...' : 'Start Quiz'}
                        </button>
                    </div>
                )}

                {gameStatus === 'playing' && questions.length > 0 && (
                    <div className="flex-grow flex flex-col p-8 md:p-12 text-left">
                        <div className="flex justify-between items-center mb-8 border-b pb-4">
                            <span className="text-sm font-bold text-gray-400">Question {currentIndex + 1}/{questions.length}</span>
                            <span className="text-sm font-bold text-brand-600">Score: {score}</span>
                        </div>
                        
                        <h3 className="text-xl md:text-2xl font-serif font-bold mb-8 text-gray-900">
                            {questions[currentIndex].question}
                        </h3>

                        <div className="space-y-3">
                            {questions[currentIndex].options.map((option, idx) => {
                                let btnClass = "w-full p-4 rounded-lg border text-left transition-all font-medium ";
                                if (showResult) {
                                    if (option === questions[currentIndex].answer) {
                                        btnClass += "bg-green-100 border-green-500 text-green-800";
                                    } else if (option === selectedOption) {
                                        btnClass += "bg-red-100 border-red-500 text-red-800";
                                    } else {
                                        btnClass += "bg-gray-50 border-gray-200 text-gray-400 opacity-50";
                                    }
                                } else {
                                    btnClass += "bg-white border-gray-200 hover:bg-brand-50 hover:border-brand-300 text-gray-700";
                                }

                                return (
                                    <button
                                        key={idx}
                                        onClick={() => !showResult && handleAnswer(option)}
                                        className={btnClass}
                                        disabled={showResult}
                                    >
                                        {option}
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                )}

                {gameStatus === 'finished' && (
                    <div className="flex-grow flex flex-col items-center justify-center p-12">
                         <div className="text-6xl mb-4">
                             {score === 5 ? '🏆' : score >= 3 ? '🌟' : '📖'}
                         </div>
                         <h3 className="text-3xl font-bold mb-2">Quiz Complete!</h3>
                         <p className="text-xl text-gray-600 mb-8">You scored <span className="font-bold text-brand-600">{score}</span> out of {questions.length}</p>
                         <div className="flex gap-4">
                             <button 
                                onClick={startGame}
                                className="px-6 py-3 bg-brand-600 text-white font-bold rounded hover:bg-brand-700"
                             >
                                Play Again
                             </button>
                             <button 
                                onClick={() => setGameStatus('idle')}
                                className="px-6 py-3 bg-gray-200 text-gray-700 font-bold rounded hover:bg-gray-300"
                             >
                                Close
                             </button>
                         </div>
                    </div>
                )}
            </div>
        </div>
    </section>
  );
};

export default QuizSection;