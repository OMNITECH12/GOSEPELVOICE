import React, { useState, useEffect } from 'react';
import { generateDailyDevotional } from '../services/geminiService';
import { Devotional } from '../types';
import { IconBrain } from './Icons';

const DevotionalSection: React.FC = () => {
  const [devotional, setDevotional] = useState<Devotional | null>(null);
  const [loading, setLoading] = useState(false);
  const [topic, setTopic] = useState('');

  const fetchDevotional = async (customTopic?: string) => {
    setLoading(true);
    const data = await generateDailyDevotional(customTopic);
    setDevotional(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchDevotional(); // Load one on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <section id="devotional" className="py-20 bg-brand-50">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-12 items-start">
          
          {/* Controls */}
          <div className="w-full md:w-1/3 bg-white p-8 rounded-xl shadow-lg border border-brand-100">
            <div className="flex items-center gap-3 mb-6 text-brand-900">
              <div className="p-3 bg-brand-100 rounded-full">
                 <IconBrain className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-serif font-bold">AI Spiritual Guide</h2>
            </div>
            <p className="text-gray-600 mb-6">
              Need encouragement on a specific topic? Enter a word (e.g., "Peace", "Faith", "Anxiety") and let our AI assistant generate a personalized devotional for you.
            </p>
            <input 
              type="text"
              placeholder="Enter topic (e.g. Hope)..."
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full p-4 border border-gray-200 rounded-lg mb-4 focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-shadow"
            />
            <button 
              onClick={() => fetchDevotional(topic)}
              disabled={loading}
              className="w-full py-3 bg-brand-900 text-white font-bold rounded-lg hover:bg-brand-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center"
            >
              {loading ? (
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
              ) : "Generate Devotional"}
            </button>
          </div>

          {/* Content Display */}
          <div className="w-full md:w-2/3">
            {loading && !devotional && (
               <div className="h-96 flex items-center justify-center bg-white rounded-xl shadow-lg border border-brand-100">
                 <div className="flex flex-col items-center gap-4 animate-pulse">
                    <div className="w-12 h-12 bg-brand-100 rounded-full"></div>
                    <div className="h-4 w-48 bg-gray-200 rounded"></div>
                    <div className="h-4 w-32 bg-gray-200 rounded"></div>
                 </div>
               </div>
            )}

            {devotional && !loading && (
              <div className="bg-white p-8 md:p-12 rounded-xl shadow-lg border-t-4 border-gold-500 relative overflow-hidden">
                <div className="absolute top-0 right-0 -mt-10 -mr-10 w-32 h-32 bg-gold-500/10 rounded-full blur-2xl"></div>
                
                <h3 className="font-serif text-3xl md:text-4xl font-bold text-brand-900 mb-4">{devotional.title}</h3>
                
                <div className="bg-brand-50 border-l-4 border-brand-500 p-6 mb-8 italic text-gray-700">
                  <p className="text-lg font-serif">"{devotional.scripture}"</p>
                </div>

                <div className="prose prose-lg text-gray-600 mb-8 leading-relaxed">
                  {devotional.content}
                </div>

                <div className="bg-gray-50 p-6 rounded-lg border border-gray-100">
                  <h4 className="text-brand-800 font-bold uppercase tracking-wider text-sm mb-2">Prayer</h4>
                  <p className="text-gray-700 italic">{devotional.prayer}</p>
                </div>
              </div>
            )}
          </div>

        </div>
      </div>
    </section>
  );
};

export default DevotionalSection;