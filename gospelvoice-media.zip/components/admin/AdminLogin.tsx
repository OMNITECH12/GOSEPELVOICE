import React, { useState } from 'react';
import { getAdmins } from '../../services/dataService';

interface AdminLoginProps {
  onLogin: () => void;
  onBack: () => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin, onBack }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // Mock Authentication Logic
    // In production, this should hit a secure backend
    const admins = getAdmins();
    const user = admins.find(a => a.email.toLowerCase() === email.toLowerCase());
    
    // For demo: password is simply 'admin123' for all users or whatever they set
    // If no user found, or specific hardcoded demo credential
    if ((user && password === 'admin123') || (email === 'admin@gospelvoice.media' && password === 'admin123')) {
       onLogin();
    } else {
       setError('Invalid credentials. Try admin@gospelvoice.media / admin123');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-brand-900 relative overflow-hidden px-4">
      {/* Decoration */}
      <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
      
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-md p-8 relative z-10">
        <div className="text-center mb-8">
           <div className="w-16 h-16 bg-brand-900 text-white rounded-lg flex items-center justify-center text-2xl font-bold mx-auto mb-4">GV</div>
           <h2 className="text-2xl font-serif font-bold text-brand-900">Admin Portal</h2>
           <p className="text-gray-500">Sign in to manage content</p>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded text-sm mb-6 text-center border border-red-100">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-5">
           <div>
             <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
             <input 
               type="email" 
               required
               value={email}
               onChange={(e) => setEmail(e.target.value)}
               className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all"
               placeholder="admin@gospelvoice.media"
             />
           </div>
           <div>
             <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
             <input 
               type="password" 
               required
               value={password}
               onChange={(e) => setPassword(e.target.value)}
               className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all"
               placeholder="••••••••"
             />
           </div>
           
           <button 
             type="submit"
             className="w-full py-3 bg-brand-600 text-white font-bold rounded hover:bg-brand-700 transition-colors shadow-md"
           >
             Sign In
           </button>
        </form>

        <div className="mt-6 text-center">
           <button onClick={onBack} className="text-sm text-gray-500 hover:text-brand-600 underline">
             Back to Website
           </button>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;