import React, { useState, useEffect } from 'react';
import { MediaItem, AdminUser, MediaType } from '../../types';
import { getMedia, saveMedia, getAdmins, saveAdmins } from '../../services/dataService';
import { IconMusic, IconUser, IconLogOut, IconGrid, IconPlus, IconTrash, IconEdit, IconSettings, IconList } from '../Icons';

interface AdminDashboardProps {
  onLogout: () => void;
  onDataChange: () => void; // Notify parent to refresh data
}

type View = 'dashboard' | 'media' | 'admins';

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout, onDataChange }) => {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Media Form State
  const [showMediaForm, setShowMediaForm] = useState(false);
  const [editingMedia, setEditingMedia] = useState<MediaItem | null>(null);
  const [formData, setFormData] = useState<Partial<MediaItem>>({});

  // Admin Form State
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setMedia(getMedia());
    setAdmins(getAdmins());
  };

  const handleDeleteMedia = (id: string) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      const updated = media.filter(m => m.id !== id);
      saveMedia(updated);
      setMedia(updated);
      onDataChange();
    }
  };

  const handleSaveMedia = (e: React.FormEvent) => {
    e.preventDefault();
    let updatedMedia = [...media];
    
    if (editingMedia) {
      updatedMedia = updatedMedia.map(m => m.id === editingMedia.id ? { ...m, ...formData } as MediaItem : m);
    } else {
      const newItem: MediaItem = {
        id: Date.now().toString(),
        title: formData.title || 'Untitled',
        author: formData.author || 'Unknown',
        description: formData.description || '',
        type: formData.type as MediaType || MediaType.MUSIC,
        thumbnailUrl: formData.thumbnailUrl || 'https://picsum.photos/400/300',
        duration: formData.duration
      };
      updatedMedia.push(newItem);
    }

    saveMedia(updatedMedia);
    setMedia(updatedMedia);
    onDataChange();
    setShowMediaForm(false);
    setEditingMedia(null);
    setFormData({});
  };

  const handleAddAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    const newAdmin: AdminUser = {
      id: Date.now().toString(),
      name: newAdminName,
      email: newAdminEmail,
      role: 'Editor'
    };
    const updated = [...admins, newAdmin];
    saveAdmins(updated);
    setAdmins(updated);
    setNewAdminName('');
    setNewAdminEmail('');
  };

  const handleDeleteAdmin = (id: string) => {
    if (window.confirm('Remove this admin?')) {
        const updated = admins.filter(a => a.id !== id);
        saveAdmins(updated);
        setAdmins(updated);
    }
  };

  const openEditMedia = (item: MediaItem) => {
    setEditingMedia(item);
    setFormData(item);
    setShowMediaForm(true);
  };

  const openAddMedia = () => {
    setEditingMedia(null);
    setFormData({ type: MediaType.MUSIC });
    setShowMediaForm(true);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex font-sans text-slate-800">
      {/* Sidebar */}
      <aside className={`bg-brand-900 text-white transition-all duration-300 flex flex-col ${isSidebarOpen ? 'w-64' : 'w-20'}`}>
         <div className="p-6 border-b border-brand-800 flex items-center gap-3">
            <div className="w-8 h-8 bg-white text-brand-900 rounded font-bold flex items-center justify-center shrink-0">GV</div>
            {isSidebarOpen && <span className="font-serif font-bold text-xl tracking-tight">Admin</span>}
         </div>
         
         <nav className="flex-grow p-4 space-y-2">
            <button 
              onClick={() => setCurrentView('dashboard')} 
              className={`w-full flex items-center gap-3 p-3 rounded transition-colors ${currentView === 'dashboard' ? 'bg-brand-800 text-white' : 'text-brand-200 hover:bg-brand-800 hover:text-white'}`}
            >
              <IconGrid /> {isSidebarOpen && "Dashboard"}
            </button>
            <button 
              onClick={() => setCurrentView('media')} 
              className={`w-full flex items-center gap-3 p-3 rounded transition-colors ${currentView === 'media' ? 'bg-brand-800 text-white' : 'text-brand-200 hover:bg-brand-800 hover:text-white'}`}
            >
              <IconMusic /> {isSidebarOpen && "Media Library"}
            </button>
            <button 
              onClick={() => setCurrentView('admins')} 
              className={`w-full flex items-center gap-3 p-3 rounded transition-colors ${currentView === 'admins' ? 'bg-brand-800 text-white' : 'text-brand-200 hover:bg-brand-800 hover:text-white'}`}
            >
              <IconUser /> {isSidebarOpen && "Administrators"}
            </button>
         </nav>

         <div className="p-4 border-t border-brand-800">
           <button onClick={onLogout} className="w-full flex items-center gap-3 p-3 text-brand-200 hover:text-white hover:bg-brand-800 rounded">
             <IconLogOut /> {isSidebarOpen && "Logout"}
           </button>
         </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto h-screen">
         <header className="bg-white shadow-sm p-6 flex justify-between items-center sticky top-0 z-10">
            <h1 className="text-2xl font-serif font-bold text-gray-800 capitalize">{currentView}</h1>
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="md:hidden text-gray-500">
               <IconList />
            </button>
         </header>

         <div className="p-6 md:p-10">
            
            {/* Dashboard Overview */}
            {currentView === 'dashboard' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-gray-500 font-medium">Total Media Items</h3>
                    <div className="p-2 bg-blue-100 text-blue-600 rounded-lg"><IconMusic /></div>
                  </div>
                  <p className="text-3xl font-bold text-brand-900">{media.length}</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-gray-500 font-medium">Active Admins</h3>
                    <div className="p-2 bg-purple-100 text-purple-600 rounded-lg"><IconUser /></div>
                  </div>
                  <p className="text-3xl font-bold text-brand-900">{admins.length}</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-gray-500 font-medium">System Status</h3>
                    <div className="p-2 bg-green-100 text-green-600 rounded-lg"><IconSettings /></div>
                  </div>
                  <p className="text-lg font-bold text-green-600">Online</p>
                  <p className="text-xs text-gray-400 mt-1">v1.0.0</p>
                </div>
              </div>
            )}

            {/* Media Manager */}
            {currentView === 'media' && (
              <div>
                <div className="flex justify-end mb-6">
                  <button 
                    onClick={openAddMedia}
                    className="flex items-center gap-2 bg-brand-600 text-white px-4 py-2 rounded hover:bg-brand-700 transition-colors shadow"
                  >
                    <IconPlus className="w-4 h-4" /> Add New Media
                  </button>
                </div>

                {showMediaForm && (
                  <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-xl w-full max-w-lg shadow-2xl overflow-hidden">
                       <div className="p-6 border-b bg-gray-50 flex justify-between items-center">
                         <h3 className="font-bold text-lg">{editingMedia ? 'Edit Media' : 'Add New Media'}</h3>
                         <button onClick={() => setShowMediaForm(false)}><IconPlus className="w-5 h-5 rotate-45 text-gray-500" /></button>
                       </div>
                       <form onSubmit={handleSaveMedia} className="p-6 space-y-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700">Title</label>
                            <input className="w-full p-2 border rounded mt-1" value={formData.title || ''} onChange={e => setFormData({...formData, title: e.target.value})} required />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                             <div>
                                <label className="block text-sm font-medium text-gray-700">Author</label>
                                <input className="w-full p-2 border rounded mt-1" value={formData.author || ''} onChange={e => setFormData({...formData, author: e.target.value})} required />
                             </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700">Type</label>
                                <select className="w-full p-2 border rounded mt-1" value={formData.type} onChange={e => setFormData({...formData, type: e.target.value as MediaType})}>
                                   {Object.values(MediaType).map(t => <option key={t} value={t}>{t}</option>)}
                                </select>
                             </div>
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700">Description</label>
                            <textarea className="w-full p-2 border rounded mt-1" rows={3} value={formData.description || ''} onChange={e => setFormData({...formData, description: e.target.value})} required />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700">Thumbnail URL</label>
                            <input className="w-full p-2 border rounded mt-1" value={formData.thumbnailUrl || ''} onChange={e => setFormData({...formData, thumbnailUrl: e.target.value})} placeholder="https://..." required />
                          </div>
                          <div className="flex justify-end gap-3 pt-4">
                            <button type="button" onClick={() => setShowMediaForm(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded">Cancel</button>
                            <button type="submit" className="px-4 py-2 bg-brand-600 text-white rounded hover:bg-brand-700">Save Item</button>
                          </div>
                       </form>
                    </div>
                  </div>
                )}

                <div className="bg-white rounded-lg shadow overflow-hidden">
                  <table className="w-full text-left">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="p-4 text-sm font-medium text-gray-500">Thumbnail</th>
                        <th className="p-4 text-sm font-medium text-gray-500">Title</th>
                        <th className="p-4 text-sm font-medium text-gray-500">Type</th>
                        <th className="p-4 text-sm font-medium text-gray-500 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {media.map(item => (
                        <tr key={item.id} className="hover:bg-gray-50">
                          <td className="p-4 w-20">
                            <img src={item.thumbnailUrl} alt="" className="w-12 h-12 rounded object-cover bg-gray-200" />
                          </td>
                          <td className="p-4">
                            <p className="font-medium text-gray-900">{item.title}</p>
                            <p className="text-xs text-gray-500">{item.author}</p>
                          </td>
                          <td className="p-4">
                            <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs font-bold">{item.type}</span>
                          </td>
                          <td className="p-4 text-right space-x-2">
                            <button onClick={() => openEditMedia(item)} className="p-2 text-gray-400 hover:text-brand-600 transition-colors" aria-label="Edit">
                               <IconEdit className="w-4 h-4" />
                            </button>
                            <button onClick={() => handleDeleteMedia(item.id)} className="p-2 text-gray-400 hover:text-red-600 transition-colors" aria-label="Delete">
                               <IconTrash className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                      {media.length === 0 && (
                         <tr>
                           <td colSpan={4} className="p-8 text-center text-gray-500">No media items found. Add some content!</td>
                         </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Admin Manager */}
            {currentView === 'admins' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 <div className="bg-white rounded-lg shadow p-6">
                   <h3 className="font-bold text-lg mb-4">Current Administrators</h3>
                   <div className="space-y-4">
                     {admins.map(admin => (
                       <div key={admin.id} className="flex items-center justify-between p-4 border border-gray-100 rounded-lg hover:border-brand-200 transition-colors">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-brand-100 text-brand-700 rounded-full flex items-center justify-center font-bold">
                              {admin.name.charAt(0)}
                            </div>
                            <div>
                               <p className="font-medium">{admin.name}</p>
                               <p className="text-xs text-gray-500">{admin.email}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                             <span className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600">{admin.role}</span>
                             {admins.length > 1 && (
                               <button onClick={() => handleDeleteAdmin(admin.id)} className="text-red-400 hover:text-red-600">
                                 <IconTrash className="w-4 h-4" />
                               </button>
                             )}
                          </div>
                       </div>
                     ))}
                   </div>
                 </div>

                 <div className="bg-white rounded-lg shadow p-6 h-fit">
                   <h3 className="font-bold text-lg mb-4">Add New Admin</h3>
                   <form onSubmit={handleAddAdmin} className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Name</label>
                        <input 
                          type="text"
                          required
                          value={newAdminName}
                          onChange={e => setNewAdminName(e.target.value)}
                          className="w-full p-2 border rounded mt-1 focus:ring-2 focus:ring-brand-500 outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Email</label>
                        <input 
                          type="email"
                          required
                          value={newAdminEmail}
                          onChange={e => setNewAdminEmail(e.target.value)}
                          className="w-full p-2 border rounded mt-1 focus:ring-2 focus:ring-brand-500 outline-none"
                        />
                      </div>
                      <button type="submit" className="w-full py-2 bg-brand-600 text-white rounded hover:bg-brand-700 font-medium">
                        Add Administrator
                      </button>
                   </form>
                 </div>
              </div>
            )}

         </div>
      </main>
    </div>
  );
};

export default AdminDashboard;