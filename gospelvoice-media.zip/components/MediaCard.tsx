import React from 'react';
import { MediaItem, MediaType } from '../types';
import { IconPlay, IconDownload, IconMusic, IconVideo, IconBook, IconMic } from './Icons';

interface MediaCardProps {
  item: MediaItem;
}

const TypeIcon = ({ type }: { type: MediaType }) => {
  switch (type) {
    case MediaType.MUSIC: return <IconMusic className="w-4 h-4" />;
    case MediaType.VIDEO: return <IconVideo className="w-4 h-4" />;
    case MediaType.EBOOK: return <IconBook className="w-4 h-4" />;
    case MediaType.SERMON: return <IconMic className="w-4 h-4" />;
    case MediaType.PODCAST: return <IconMic className="w-4 h-4" />;
    default: return null;
  }
};

const MediaCard: React.FC<MediaCardProps> = ({ item }) => {
  return (
    <div className="group bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col h-full">
      <div className="relative overflow-hidden aspect-video bg-gray-100">
        <img 
          src={item.thumbnailUrl} 
          alt={item.title} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-brand-900/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
           <button className="bg-white/90 p-3 rounded-full text-brand-900 hover:bg-brand-500 hover:text-white transition-colors shadow-lg transform scale-90 group-hover:scale-100 duration-200">
             <IconPlay className="w-6 h-6 fill-current" />
           </button>
        </div>
        <div className="absolute top-2 right-2 bg-brand-900/80 backdrop-blur-sm text-white text-xs px-2 py-1 rounded flex items-center gap-1">
           <TypeIcon type={item.type} />
           {item.type}
        </div>
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <h3 className="font-serif font-bold text-lg text-brand-950 mb-1 line-clamp-1">{item.title}</h3>
        <p className="text-sm text-brand-700 font-medium mb-2">{item.author}</p>
        <p className="text-gray-500 text-sm line-clamp-2 mb-4 flex-grow">{item.description}</p>
        
        <div className="flex items-center justify-between pt-3 border-t border-gray-100 mt-auto">
           <span className="text-xs text-gray-400">{item.duration || 'PDF'}</span>
           <button className="text-brand-600 hover:text-brand-800 text-sm font-bold flex items-center gap-1 transition-colors">
             <IconDownload className="w-4 h-4" />
             Download
           </button>
        </div>
      </div>
    </div>
  );
};

export default MediaCard;