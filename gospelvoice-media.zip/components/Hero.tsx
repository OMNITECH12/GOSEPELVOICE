import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="relative w-full h-[600px] bg-brand-900 flex items-center overflow-hidden">
      {/* Abstract Background Overlay */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
         <div className="absolute top-0 left-0 w-full h-full bg-[url('https://picsum.photos/1920/1080?grayscale&blur=2')] bg-cover bg-center"></div>
         <div className="absolute inset-0 bg-gradient-to-r from-brand-950 via-brand-900 to-brand-800 mix-blend-multiply"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl">
          <span className="inline-block py-1 px-3 rounded-full bg-brand-800/50 border border-brand-600 text-brand-100 text-sm font-medium mb-6 tracking-wide backdrop-blur-md">
            WELCOME TO GOSPELVOICE MEDIA
          </span>
          <h1 className="font-serif text-5xl md:text-7xl font-bold text-white leading-tight mb-6 drop-shadow-lg">
            Proclaiming Truth, <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-300 to-white">Inspiring Souls.</span>
          </h1>
          <p className="text-brand-100 text-lg md:text-xl mb-8 leading-relaxed max-w-2xl font-light border-l-4 border-gold-500 pl-6">
            Access a sanctuary of spiritual resources. From soul-stirring sermons to uplifting music and insightful devotionals, we are dedicated to spreading the Gospel.
          </p>
          <div className="flex flex-wrap gap-4">
            <a href="#media" className="px-8 py-4 bg-gold-500 hover:bg-gold-600 text-white font-bold rounded shadow-lg hover:shadow-gold-500/30 transition-all transform hover:-translate-y-1">
              Explore Library
            </a>
            <a href="#devotional" className="px-8 py-4 bg-transparent border border-white text-white font-bold rounded hover:bg-white hover:text-brand-900 transition-all">
              Today's Devotional
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;